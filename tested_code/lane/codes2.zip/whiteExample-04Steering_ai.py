import cv2
import numpy as np

# Predefined positions for left and right x-coordinates
pre_leftx = 200
pre_rightx = 960
threshold = 100
offset_x = 10

def region_of_interest(img, vertices, color3=(255, 255, 255), color1=255):
    """ Applies an image mask, only keeping the region of the image defined by the polygon formed from `vertices`. """
    mask = np.zeros_like(img)

    # If the image has more than one color channel, use color3, otherwise use color1
    color = color3 if len(img.shape) > 2 else color1

    # Fill the polygon with the color
    cv2.fillPoly(mask, vertices, color)

    # Returning the image only where the mask pixels are nonzero
    ROI_image = cv2.bitwise_and(img, mask)
    return ROI_image

def mark_img(roi_img, image, blue_threshold=200, green_threshold=200, red_threshold=200):
    """ Marks the region of interest in the image based on color thresholds. """
    mark = np.copy(roi_img)
    thresholds = (image[:, :, 0] < blue_threshold) | (image[:, :, 1] < green_threshold) | (image[:, :, 2] < red_threshold)
    mark[thresholds] = [0, 0, 0]
    return mark

def img_process(img, color_thresholds):
    """ Processes the image to apply color thresholding and calculate steering direction. """
    global pre_leftx, pre_rightx, threshold, offset_x
    height, width = img.shape[:2]

    # Define margins and widths
    x_margin, x_width, y_min, y_max = int(0.2 * width), int(0.25 * width), int(0.75 * height), int(0.8 * height)
    y_middle = int((y_min + y_max) / 2)

    # Draw rectangles on the lanes
    cv2.rectangle(img, (x_margin, y_min), (x_margin + x_width, y_max), (150, 150, 100), 2)
    cv2.rectangle(img, (width - x_width - x_margin, y_min), (width - x_margin, y_max), (150, 150, 100), 2)

    # Extracting coordinates for left and right lanes
    l_x = color_thresholds[y_min: y_max, x_margin: x_margin + x_width].nonzero()[1]
    r_x = color_thresholds[y_min: y_max, width - x_margin - x_width: width - x_margin].nonzero()[1]

    # Calculate new positions or use previous positions if below threshold
    leftx = np.average(l_x) + x_margin if len(l_x) > threshold else pre_leftx
    rightx = np.average(r_x) + (width - x_margin - x_width) if len(r_x) > threshold else pre_rightx

    # Calculate midpoint and update previous x positions
    midx = int((leftx + rightx) / 2)
    pre_leftx, pre_rightx = leftx, rightx

    # Draw circles and line for steering direction
    cv2.circle(img, (int(leftx), y_middle), 10, 0, -1)
    cv2.circle(img, (int(rightx), y_middle), 10, 0, -1)
    cv2.circle(img, (int(midx), y_middle), 10, (255, 0, 0), -1)

    # Calculate steering angle
    steer = np.arctan2(midx - (width/2) - offset_x, height - y_middle)
    steer = round(steer, 2)
    cv2.line(img, (width//2 + offset_x, height), (midx, y_middle), (255, 0, 0), 3)
    cv2.putText(img, str(steer), (width//2 - 150, height - 40), cv2.FONT_HERSHEY_DUPLEX, 2, (255, 0, 0), 2)

    return img, steer

# Load image and define parameters
image = cv2.imread('solidWhiteCurve.jpg')
vertices = np.array([[(10, image.shape[0]), (image.shape[1] // 2 - 60, image.shape[0] // 2 + 60),
                      (image.shape[1] // 2 + 60, image.shape[0] // 2 + 60), (image.shape[1] - 10, image.shape[0])]],
                    dtype=np.int32)

roi_img = region_of_interest(image, vertices, (0, 0, 255))
mark = mark_img(roi_img, image)

# Define color thresholds and process image
color_thresholds = (mark[:, :, 0] == 0) & (mark[:, :, 1] == 0) & (mark[:, :, 2] > 200)
image[color_thresholds] = [0, 0, 255]

img, steer = img_process(image, color_thresholds)
print(steer)

# Display the images
# cv2.imshow('ROI Image', roi_img)
cv2.imshow('Processed Image', img)
cv2.waitKey(0)
cv2.destroyAllWindows()
